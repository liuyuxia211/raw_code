# ta. Comparative results with the state-of-the-art FL methods also validate the superiority of CReFF.

### Dependencies

* python 3.8.10 (Anaconda)
* PyTorch 1.10.1
* torchvision 0.11.2
* CUDA 11.4

### Dataset

- CIFAR-10
- CIFAR-100
- Tiny-ImageNet-LT

### Usage

rucr.sh
