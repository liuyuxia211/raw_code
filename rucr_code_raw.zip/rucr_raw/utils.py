from enum import unique
from random import shuffle
from pytest import param
import torch
import numpy as np
import time
import numpy as np
import matplotlib.pyplot as plt
import os
from sklearn import datasets as ds
from sklearn.manifold import TSNE
import os
from torchvision import datasets
from torchvision.transforms import ToTensor, transforms
import numpy as np
from torch.utils.data.dataloader import DataLoader
import torch
from Dataset.dataset import *
import matplotlib.pyplot as plt
from Model.ResNet50 import ResNet50
from Model.Resnet8 import *
from Model.Resnet8_norm import *
from torchvision.transforms import ToTensor, transforms
from Dataset.long_tailed_cifar10 import *
from torch.optim import SGD
from torch.nn import CrossEntropyLoss



def model_fusion(list_dicts_local_params: list, list_nums_local_data: list):
    # fedavg
    local_params = copy.deepcopy(list_dicts_local_params[0])
    for name_param in list_dicts_local_params[0]:
        list_values_param = []
        for dict_local_params, num_local_data in zip(list_dicts_local_params, list_nums_local_data):
            list_values_param.append(dict_local_params[name_param] * num_local_data)
        value_global_param = sum(list_values_param) / sum(list_nums_local_data)
        local_params[name_param] = value_global_param
    return local_params

def get_mean(args,feat_dim,c_infos,nums):
    real_info = dict()
    syn_info = [torch.zeros(feat_dim).to(args.device)]*args.num_classes
    nums = np.array(nums)
    cls_total = np.sum(nums,axis=0)
    for cls in range(args.num_classes):
        for c_idx , c_info in enumerate(c_infos):
            if cls not in c_info.keys():
                continue
            pre = real_info.get(cls,0)
            real_info[cls] = pre + c_info[cls] * nums[c_idx][cls]
        if real_info.get(cls) == None:
            continue
        temp = real_info.get(cls)
        real_info[cls] = temp / cls_total[cls]

    real_id = []
    for k,v in real_info.items():
        real_id.append(k)
        syn_info[k] = v
    syn_info = torch.stack(syn_info).to(args.device)
    return real_info,syn_info,real_id

def get_vars_mean(vars,means,num_per_cls=None):
    if num_per_cls == None:
        if type(vars) == dict:
            var_list = list(vars.values())
            temp_var = sum(var_list)/len(var_list)
    else:
        total = sum(num_per_cls)
        if total <= 1:
            return torch.zeros(1)

        total_mean = 0
        for cls,mean in means.items():
            total_mean += num_per_cls[cls] / total * mean

        temp_var = 0
        for cls,var in vars.items():
            num = num_per_cls[cls]
            temp_var += (num - 1) * var + num * means[cls].pow(2)
        temp_var -= total * total_mean.pow(2)
        temp_var /= total - 1
    if min(temp_var) < 0:
        mylog = getLogger()
        mylog.write("find var less than zero !:"+str(min(temp_var)))
    
    if min(temp_var) == 0:
        temp_var.clamp(1e-5,max(temp_var))
        
    var_mean = temp_var
    return var_mean

def get_cls_cov_from_feats(feats_all,labels_all):
    feats_all = torch.cat(feats_all,dim=0)
    labels_all = torch.cat(labels_all)
    feat_dim = feats_all[0].shape[0]
    device = feats_all.device
    real_cls = labels_all.unique()          
    cls_std,cls_fs,cls_means,cls_var = dict(),dict(),dict(),dict()
    for cls in real_cls.tolist():
        cls_feat = feats_all[labels_all == cls]
        cls_fs[cls] = cls_feat
        cls_means[cls] = cls_feat.mean(dim=0)
        temp_var = cls_feat.var(dim=0)
        if cls_feat.shape[0] == 1:
            temp_var = torch.zeros((feat_dim)).to(device)
        cls_var[cls] = temp_var
        cls_std[cls] = temp_var.sqrt()
    return cls_std,cls_means,cls_fs,cls_var

def getModel(path,sub=None,device='cuda:0'):
    if 'image' in path:
        net = ResNet50(200)
    cls,our = None,None
    if '10' in path:
        cls = 10
    if '100' in path:
        cls = 100

    if 'feat' in path:
        our = True
        
    net = ResNet_cifar(resnet_size=8, scaling=4,
                                save_activations=False, group_norm_num_groups=None,
                                freeze_bn=False, freeze_bn_affine=False, num_classes=cls).to(device)
    if our:
        net = ResNet_cifar_norm(resnet_size=8, scaling=4,
                                    save_activations=False, group_norm_num_groups=None,
                                    freeze_bn=False, freeze_bn_affine=False, num_classes=cls).to(device)

    save_path = path
    # model_para_path = save_path +'best_model_param.pth' 
    model_para_path = os.path.join(save_path,'best_model_param.pth') 
    if sub:
        model_para_path = save_path + sub
    net.load_state_dict(torch.load(model_para_path))
    return net

