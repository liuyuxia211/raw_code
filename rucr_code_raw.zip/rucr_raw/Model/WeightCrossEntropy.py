from turtle import forward
import torch
import torch.nn as nn

class WeightCrossEntropy(nn.Module):
    def __init__(self,weight):
        super(WeightCrossEntropy,self).__init__()
        self.logsoft = nn.LogSoftmax(dim=1)
        self.nll = nn.NLLLoss()
        self.w = weight
    def forward(self,input,target):
        input = self.logsoft(input)
        
        
