
from __future__ import absolute_import
import copy,os,csv
from re import A
import os
import sys
import os
import errno
save_dict = {'num_classes':'nc','imb_factor':'lt','non_iid_alpha':'beta','cos_arg':'cos','num_clients':'cnum',
'num_online_clients':'onnum','num_rounds':'gep','num_epochs_local_training':'cep',
'batch_size_local_training':'bs','lr_local_training':'lr','first_epoch':'first','feat_regular_way':'way',
'cos_cls_arg':'coscls','knn_cls':'knn','knn_feat_type':'kft','knn_dist_type':'kdt','aggre_proto':'agg',
'cos_agg_instance_arg':'cosaggins','cos_agg_cls_arg':'cosaggcls','cos_cls_instance_arg':'cosaggclsins',
'lr_cls_balance':'lrbal','epoch_cls_balance':"epcls",'t':'t','crt':'crt','crt_all':'crtall','bal_nce':'balnce',
'feat_loss_type':'fltype','feat_loss_arg':'flarg','crt_feat_num':'crtnum','crt_way':'crtway','detail_fusion':'dfu',
'crt_time':'crtt','crt_ep':'crep','adaptive':'ad','crt_ep_com':'crepc','crt_first':'crf','feat_first':'ff',
'fl_last':'fll','fl_ep':'fep','con':'c','num_of_feature':'numf','crt_bal_ep':'crbal','mix':'m','mix_t':'mt','a':'a',
'log_t':'logt','glo_dis':'gdis','inver':'iv','times':'ti'
}
inverse_dict = {v:k for k,v in save_dict.items()}

exclude_list = ['path_cifar10','path_cifar100','batch_size_local_training','batch_real','lr_feature','batch_size_test',
'device','seed','imb_type','save_path','match_epoch','crt_epoch','batch_real',]
way_list = ['feat_regular_way']

myloger = None
def setLogger(l):
    global myloger
    myloger = l
def getLogger():
    global myloger
    return myloger



def base_path(args):
    if args.log_path == ' ':
        return './data'
    else: 
        create_if_not_exists(args.log_path)
        return args.log_path
def create_if_not_exists(path: str) -> None:
    if not os.path.exists(path):
        os.makedirs(path)


log_global_path = None
def write_args(args):
    args = copy.deepcopy((args))
    log_base_path = base_path(args)
    args = vars(args)
    for key, value in args.items():
        args[key] = str(value)

    paragroup_dirs = os.listdir(log_base_path)
    n_para = len(paragroup_dirs)
    exist_para = False

    temp_arg = dict()
    for k,v in args.items():
        if k in exclude_list or k not in save_dict.keys() or v.isdigit() and float(v) == 0 or v == '0.0':
            continue
        temp_arg[k] = v
    key_len = len(temp_arg.items())

    for para in sorted(paragroup_dirs,reverse=False):
        para_path = os.path.join(log_base_path, para)
        for csvpath in os.listdir(para_path):
            if 'lr' in csvpath:
                hparams = csvpath.split('_')[:-1]
                if len(hparams)/2 != key_len:
                    break
                exist_para = True
                path = para_path
                i = 0 
                while i < len(hparams):
                    k = inverse_dict[hparams[i]]
                    if k not in temp_arg.keys() or  temp_arg[k] != hparams[i+1]:
                        exist_para = False
                        break
                    i += 2
        if exist_para:
            break

    exist_para = False
    if exist_para == False:
        model_folder_path = log_base_path
        n_para = 0
        path = os.path.join(model_folder_path, 'para' + str(n_para + 1))
        k=1
        while os.path.exists(path):
            path = os.path.join(model_folder_path, 'para' + str(n_para +k))
            k = k+1
        create_if_not_exists(path)

        columns = list(args.keys())
        write_headers = True
        joinpath = '/'
        for k,v in temp_arg.items():
            joinpath += save_dict[k]
            joinpath += '_'
            joinpath += v
            joinpath += '_' 
        args_path = path+joinpath+'.csv'
        with open(args_path, 'a') as tmp:
            writer = csv.DictWriter(tmp, fieldnames=columns)
            if write_headers:
                writer.writeheader()
            writer.writerow(args)
    global log_global_path
    log_global_path = path
    return path

def write_acc(acc,path):
    acc_path = path+'/acc.txt'
    max_acc = max(acc)
    with open(acc_path,'a') as tmp:
        tmp.write(str(acc)+"\n")
        tmp.write(str(max_acc)+"\n")

def mkdir_if_missing(dir_path):
    try:
        os.makedirs(dir_path)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

class Logger(object):
    def __init__(self, fpath=None):
        self.console = sys.stdout
        self.file = None
        self.save = sys.stderr

        if fpath is not None:
            mkdir_if_missing(os.path.dirname(fpath))
            self.file = open(fpath, 'w')
            sys.stderr = self.file

    def __del__(self):
        self.close()

    def __enter__(self):
        pass

    def __exit__(self, *args):
        sys.stderr = self.save
        self.close()

    def write(self, msg):
        self.console.write(msg)
        self.console.write('\n')
        if self.file is not None:
            self.file.write(msg)
            self.file.write('\n')
        self.flush()


    def flush(self):
        self.console.flush()
        if self.file is not None:
            self.file.flush()
            os.fsync(self.file.fileno())

    def close(self):
        self.console.close()
        if self.file is not None:
            self.file.close()